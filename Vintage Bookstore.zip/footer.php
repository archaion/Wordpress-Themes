<footer>
    <p>&copy; <a href="https://github.com/sunvvheel/">Sunwheel Studios</a></p>
    <p id="line2"></p>
</footer>
</div>
<div id='corner'></div>
<?php //wp_footer(); 
?>
</body>

</html>
<script>
    //JAVASCRIPT GOES HERE
</script>