<footer>
    <p>&copy; 2021 <a href="https://github.com/sunvvheel/">
            Sunwheel Studios</a></p>
</footer>
</div>
<div id='corner'></div>
<?php //wp_footer(); 
?>
</body>
</html>
<script>
    //JAVASCRIPT GOES HERE
</script>