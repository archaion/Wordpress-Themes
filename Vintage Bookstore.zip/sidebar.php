<aside id="sidebar">
    <ul>
        <?php //dynamic_sidebar('Custom Menu'); 
        ?>
        <h3 class="widget-title"></h3>
        <li id="%1$s" class="widget-container %2$s"> Featured Item</li>
        <h3 class="widget-title"></h3>
        <li id="%1$s" class="widget-container %2$s"> Featured Item</li>
        <h3 class="widget-title"></h3>
        <li id="%1$s" class="widget-container %2$s"> Featured Item</li>
    </ul>
    <div id="corner2"></div>
    <div id="corner3"></div>
</aside>