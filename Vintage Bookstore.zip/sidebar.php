<aside id="sidebar">
    <ul>
        <h3 class="widget-title">Featured</h3>
        <li class="widget-container"> Art Stuff </li>
        <li class="widget-container"> Random Book </li>
        <li class="widget-container"> Some Photos </li>
    </ul>
    <div id="corner2"></div>
    <div id="corner3"></div>
</aside>